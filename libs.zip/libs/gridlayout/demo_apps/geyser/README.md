## Geyser app

### Purpose
This is a kind-of "Minimum viable example", where we take the classic geyser app and recreate it using `gridlayout::grid_page()`

### Screenshots
- `tests/screenshot-tests/_snaps/demo-apps/geyser-app.png`
